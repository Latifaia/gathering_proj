
<!DOCTYPE html>
<html>

<head>
<title>home page</title>
<meta charset="UTF-8">
<link rel="stylesheet" href="web.css"> 
<link rel="stylesheet" href="general.css"> 
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="web.js"></script> 

</head>

<body>
  <header>
        <img src="logo3.png" alt="logo" id="logo">
       <!-- <h1>Taste of Saudi</h1>-->
      <div id="under-header"></div>

  </header>




<main>
    <!--<button id="button"><strong>log in</strong></button>-->
  <div id="all">
    <br>
    <em><p style="font-size:larger;">"Home is where the heart is"</p></em>
    <p>New user?</p>
    <button class="b"><a href="signup.php" style='text-decoration:none;'>Sign-up</a></button>
    
      <p>Already have an account?</p>
   
        <div class="dropdown">
            <button class="dropbtn">Log-in</button>
      <div class="dropdown-content">
        <a href="loginS.php">Home seeker</a>
        <a href="loginO.php" >Home owner</a>
      </div>
    </div>
  </div>
</main>




<footer>
    <div class="foot">
      
      <div class="w3-xlarge w3-section">
          <i class="fa fa-facebook-official w3-hover-opacity"></i>
          <i class="fa fa-instagram w3-hover-opacity"></i>
          <i class="fa fa-snapchat w3-hover-opacity"></i>
          <i class="fa fa-pinterest-p w3-hover-opacity"></i>
          <i class="fa fa-twitter w3-hover-opacity"></i>
          <i class="fa fa-linkedin w3-hover-opacity"></i>
      </div>
        <p>@2023 Home Properties</p></div>

</footer>
</body>

</html>
