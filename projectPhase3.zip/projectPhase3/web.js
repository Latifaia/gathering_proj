function signup() {
 window.location.replace("signup.php");    
    
}


 