
pageName="";

function homepage() {
 window.location.replace("index.php");    
    
}

function login() {
 window.location.replace("login.php");    
    
}

function Edit() {
 window.location.replace("Edit_property.php");    
    
}

